import { Link } from "react-router-dom";
import { useCart } from "../context/CartContext";

export default function Navbar() {
  const { cart } = useCart();

  const count = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <nav className="navbar">
      <Link to="/" className="logo">
        ShopLine
      </Link>

      <div>
        <Link to="/">Home</Link>
        <Link to="/cart">Cart ({count})</Link>
      </div>
    </nav>
  );
}
