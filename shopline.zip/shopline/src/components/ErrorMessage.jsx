export default function ErrorMessage() {
  return <h2 className="error-message">Something went wrong.</h2>;
}
