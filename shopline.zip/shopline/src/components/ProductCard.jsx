import { Link } from "react-router-dom";
import { useCart } from "../context/CartContext";

export default function ProductCard({ product }) {
  const { addToCart } = useCart();

  return (
    <div className="card">
      <Link to={`/product/${product.id}`}>
        <img src={product.thumbnail} alt={product.title} />
      </Link>

      <h3>{product.title}</h3>

      <p>₹ {product.price}</p>

      <p>⭐ {product.rating}</p>

      <button onClick={() => addToCart(product)}>Add To Cart</button>
    </div>
  );
}
