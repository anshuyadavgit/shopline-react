import { useCart } from "../context/CartContext";

export default function Cart() {
  const {
    cart,
    increaseQty,
    decreaseQty,
    removeItem,
    subtotal,
    tax,
    delivery,
    total,
  } = useCart();

  if (cart.length === 0) {
    return <h1 className="empty">Your Cart is Empty</h1>;
  }

  return (
    <div className="cart-page">
      <div className="cart-items">
        {cart.map((item) => (
          <div className="cart-card" key={item.id}>
            <img src={item.thumbnail} alt={item.title} />

            <div>
              <h2>{item.title}</h2>

              <h3>₹ {item.price}</h3>

              <div>
                <button onClick={() => decreaseQty(item.id)}>-</button>

                <span>{item.quantity}</span>

                <button onClick={() => increaseQty(item.id)}>+</button>
              </div>

              <button onClick={() => removeItem(item.id)}>Remove</button>
            </div>
          </div>
        ))}
      </div>

      <div className="bill">
        <h2>Bill Summary</h2>

        <p>Subtotal : ₹ {subtotal.toFixed(2)}</p>

        <p>GST (18%) : ₹ {tax.toFixed(2)}</p>

        <p>Delivery : ₹ {delivery.toFixed(2)}</p>

        <hr />

        <h2>Total : ₹ {total.toFixed(2)}</h2>
      </div>
    </div>
  );
}
