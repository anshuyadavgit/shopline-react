import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { getProduct } from "../api/products";
import Loader from "../components/Loader";
import ErrorMessage from "../components/ErrorMessage";
import { useCart } from "../context/CartContext";

export default function ProductDetails() {
  const { id } = useParams();

  const { addToCart } = useCart();

  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    async function loadProduct() {
      try {
        const data = await getProduct(id);
        setProduct(data);
      } catch (err) {
        setError(true);
      } finally {
        setLoading(false);
      }
    }

    loadProduct();
  }, [id]);

  if (loading) return <Loader />;
  if (error || !product) return <ErrorMessage />;

  return (
    <div className="details">
      <img src={product.thumbnail} alt={product.title} />

      <div>
        <h1>{product.title}</h1>

        <p>{product.description}</p>

        <h3>Category : {product.category}</h3>

        <h3>Brand : {product.brand}</h3>

        <h2>₹ {product.price}</h2>

        <h3>⭐ {product.rating}</h3>

        <h3>Discount : {product.discountPercentage}%</h3>

        <h3>Stock : {product.stock}</h3>

        <button onClick={() => addToCart(product)}>Add To Cart</button>
      </div>
    </div>
  );
}
