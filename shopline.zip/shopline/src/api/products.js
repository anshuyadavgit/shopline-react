import axios from "axios";

const api = axios.create({
  baseURL: "https://dummyjson.com",
});

// Fetch all products (used by the Listing page)
export const getProducts = async () => {
  const res = await api.get("/products?limit=194");
  return res.data.products;
};

// Fetch a single product by id (used by the Product Details page)
export const getProduct = async (id) => {
  const res = await api.get(`/products/${id}`);
  return res.data;
};
